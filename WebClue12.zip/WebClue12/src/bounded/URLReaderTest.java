package bounded;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class URLReaderTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入一个URL");
		String urlString = scanner.next();
		try {
			URL url = new URL(urlString);
			urlReader(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void urlReader(URL url){
		//获取协议名
		String protocol = url.getProtocol();
		//获取主机名
		String host = url.getHost();
		//获取端口号
		int port = url.getPort();
		//获取文件名
		String file = url.getFile();
		//获取锚点（引用）
		String ref = url.getRef();
		//获取查询信息
		String query = url.getQuery();
		//获取路径
		String path = url.getPath();
		//获取权限信息
		String authority = url.getAuthority();
		//获取使用者的信息
		String userinfo = url.getUserInfo();
		System.out.println("协议名："+protocol);
		System.out.println("主机名："+ host);
		System.out.println("端口号："+port);
		System.out.println("文件名："+file);
		System.out.println("锚点："+ref);
		System.out.println("查询信息："+query);
		System.out.println("路径："+path);
		System.out.println("权限信息："+authority);
		System.out.println("使用者信息："+userinfo);
	}

}

