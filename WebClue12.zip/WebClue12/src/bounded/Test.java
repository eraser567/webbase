package bounded;
import it.unimi.dsi.lang.MutableString;
import it.unimi.dsi.logging.ProgressLogger;
import it.unimi.dsi.webgraph.GraphClassParser;
import it.unimi.dsi.webgraph.ImmutableGraph;
import it.unimi.dsi.webgraph.LazyIntIterator;
import it.unimi.dsi.webgraph.NodeIterator;
import it.unimi.dsi.util.PermutedFrontCodedStringList;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.spec.ECFieldF2m;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.JSAP;
import com.martiansoftware.jsap.JSAPException;
import com.martiansoftware.jsap.JSAPResult;
import com.martiansoftware.jsap.Parameter;
import com.martiansoftware.jsap.SimpleJSAP;
import com.martiansoftware.jsap.Switch;
import com.martiansoftware.jsap.UnflaggedOption;

public class Test {

	@SuppressWarnings("unchecked")
	static public void main( String arg[] ) throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, JSAPException, IOException {
		SimpleJSAP jsap = new SimpleJSAP( BreadthFirst.class.getName(), "Visits a graph in breadth-first fashion, possibly starting just from a given node.",
				new Parameter[] {
						new FlaggedOption( "graphClass", GraphClassParser.getParser(), null, JSAP.NOT_REQUIRED, 'g', "graph-class", "Forces a Java class for the source graph." ),
						new FlaggedOption( "logInterval", JSAP.LONG_PARSER, Long.toString( ProgressLogger.DEFAULT_LOG_INTERVAL ), JSAP.NOT_REQUIRED, 'l', "log-interval", "The minimum time interval between activity logs in milliseconds." ),
						new Switch( "print", 'p', "print", "Print nodes as they are enqueued. If set, ordinary output is suppressed." ),
						new UnflaggedOption( "basename", JSAP.STRING_PARSER, JSAP.NO_DEFAULT, JSAP.REQUIRED, JSAP.NOT_GREEDY, "The basename of the graph." ),
					}		
				);
		
		JSAPResult jsapResult = jsap.parse( arg );
		if ( jsap.messagePrinted() ) System.exit( 1 );

		final ProgressLogger pl = new ProgressLogger();
		pl.logInterval = jsapResult.getLong( "logInterval" );
		final String basename = jsapResult.getString( "basename" );
		final ImmutableGraph graph;
		if ( jsapResult.userSpecified( "graphClass" ) ) graph = (ImmutableGraph)(jsapResult.getClass( "graphClass" )).getMethod( "load", CharSequence.class, ProgressLogger.class ).invoke( null, basename, pl );
		else graph = ImmutableGraph.load( basename, pl );
		
		final int n = graph.numNodes();
		
		readfile rf = new readfile();
		PermutedFrontCodedStringList pList = (PermutedFrontCodedStringList)rf.read(basename+".fcl");
				
		pl.start( "Starting visit...graph.numNodes()=" + n);
		pl.itemsName = "nodes";
		
		int count = 0, num_nodes=graph.numNodes();
		HashMap<String, Integer> label_count=new HashMap<String, Integer>(10000000);
		
		final NodeIterator nodeIterator = graph.nodeIterator();
		for( int i = n; i-- != 0; ) {
			int curr = nodeIterator.nextInt();
			LazyIntIterator successors = graph.successors( curr );
			int d = graph.outdegree( curr );

			MutableString label=new MutableString();
			pList.get(curr, label);
			//String new_label=getMyLabel(label.toString());
			String host = getHost(label.toString());
			
			if (!label_count.containsKey(host)) {
				label_count.put(host, 0);
			}
			label_count.put(host,label_count.get(host)+1);

			/*System.out.print("[" + curr + "; deg=" + d + "; label=" + new_label + "] -> {");
			while( d-- != 0 ) {
				int succ = successors.nextInt();
				System.out.print(succ + ",");
			}
			System.out.println("}");*/

			count ++;
			if (count %1000000 ==0 ) System.out.println("progress = " + count + "/" + num_nodes);;
		}
		
		System.out.println("number of webpages=" + count);
		System.out.println("number of labels  =" + label_count.size());
		
		int granularity = 1000000;
		int[] distr = new int[granularity];
		for (String k : label_count.keySet()) {
			double d = label_count.get(k);
			int c = (int) (d/count*granularity); 
			distr[c] ++;
		}
		FileWriter fw = new FileWriter("host_count.distr");
		fw.write("number of webpages=" + count+"\n");
		fw.write("number of labels  =" + label_count.size()+"\n");
		int fw_count=0;
		for (int i = 0; i < granularity; i ++) {
			if (distr[i] > 10) {
				fw.write(i + ": " + distr[i] + "\n");				
				fw_count ++;
			}
		}
		fw.close();
		System.out.println("fw_count=" + fw_count);
		
		fw = new FileWriter("host_count.txt");
		for (String k : label_count.keySet()) {
			fw.write(k + "\t" + label_count.get(k) + "\n");
		}
		fw.close();

		pl.done();
	}
	
	public static String getHost (String l) {
		try {
			URL url = new URL(l);
			
			String host = url.getHost();
			return host;
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return "s1335233hrz";
	}
	
	public static String getMyLabel (String l) {
		try {
			URL url = new URL(l);
			
			String host = url.getHost();
			String path = url.getPath();
			int count=0, pos=path.indexOf('/', 0);
			while (pos >= 0) {
				count ++;
				if (count >= 3) {
					break;
				}
				pos=path.indexOf('/', pos+1);
			}
			return host+count;
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return "s1335233hrz";
	}
}
