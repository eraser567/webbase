package bounded;

import it.unimi.dsi.lang.MutableString;
import it.unimi.dsi.logging.ProgressLogger;
import it.unimi.dsi.util.PermutedFrontCodedStringList;
import it.unimi.dsi.webgraph.GraphClassParser;
import it.unimi.dsi.webgraph.ImmutableGraph;
import it.unimi.dsi.webgraph.LazyIntIterator;
import it.unimi.dsi.webgraph.NodeIterator;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import bounded.encode.EncodeLabel;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.JSAP;
import com.martiansoftware.jsap.JSAPException;
import com.martiansoftware.jsap.JSAPResult;
import com.martiansoftware.jsap.Parameter;
import com.martiansoftware.jsap.SimpleJSAP;
import com.martiansoftware.jsap.Switch;
import com.martiansoftware.jsap.UnflaggedOption;

public class GetEncodeGraph {
	@SuppressWarnings("unchecked")
	static public void main( String arg[] ) throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, JSAPException, IOException, Exception {
		SimpleJSAP jsap = new SimpleJSAP( BreadthFirst.class.getName(), "Visits a graph in breadth-first fashion, possibly starting just from a given node.",
				new Parameter[] {
						new FlaggedOption( "graphClass", GraphClassParser.getParser(), null, JSAP.NOT_REQUIRED, 'g', "graph-class", "Forces a Java class for the source graph." ),
						new FlaggedOption( "logInterval", JSAP.LONG_PARSER, Long.toString( ProgressLogger.DEFAULT_LOG_INTERVAL ), JSAP.NOT_REQUIRED, 'l', "log-interval", "The minimum time interval between activity logs in milliseconds." ),
						new Switch( "print", 'p', "print", "Print nodes as they are enqueued. If set, ordinary output is suppressed." ),
						new UnflaggedOption( "basename", JSAP.STRING_PARSER, JSAP.NO_DEFAULT, JSAP.REQUIRED, JSAP.NOT_GREEDY, "The basename of the graph." ),
					}		
				);
		
		JSAPResult jsapResult = jsap.parse( arg );
		if ( jsap.messagePrinted() ) System.exit( 1 );

		final ProgressLogger pl = new ProgressLogger();
		pl.logInterval = jsapResult.getLong( "logInterval" );
		final String basename = jsapResult.getString( "basename" );
		final ImmutableGraph graph;
		if ( jsapResult.userSpecified( "graphClass" ) ) graph = (ImmutableGraph)(jsapResult.getClass( "graphClass" )).getMethod( "load", CharSequence.class, ProgressLogger.class ).invoke( null, basename, pl );
		else graph = ImmutableGraph.load( basename, pl );
		
		final int n = graph.numNodes();
		
		readfile rf = new readfile();
		PermutedFrontCodedStringList pList = (PermutedFrontCodedStringList)rf.read(basename+".fcl");
				
		pl.start( "Starting visit...graph.numNodes()=" + n);
		pl.itemsName = "nodes";
		
		EncodeLabel el = new EncodeLabel();
		HashMap<String, Integer> label_lid = el.readLabelId1();
		System.out.println("label_lid is loaded!");
		
		int count = 0, num_nodes=graph.numNodes();
		int min_node_id = Integer.MAX_VALUE;
		int max_node_id = Integer.MIN_VALUE;
				
		OutputStreamWriter fw_node = new OutputStreamWriter(new FileOutputStream("label.txt"),"UTF-8");
		OutputStreamWriter fw_edge = new OutputStreamWriter(new FileOutputStream("edge.txt"),"UTF-8");
		
		StringBuilder sb_node = new StringBuilder("");
		StringBuilder sb_edge = new StringBuilder("");
		sb_node.ensureCapacity(1600000);
		sb_edge.ensureCapacity(2000000);
		int sb_node_count = 0;
		int sb_edge_count = 0;
		
		final NodeIterator nodeIterator = graph.nodeIterator();
		for( int i = n; i-- != 0; ) {
			int curr = nodeIterator.nextInt();
			LazyIntIterator successors = graph.successors( curr );
			int d = graph.outdegree( curr );

			MutableString label=new MutableString();
			pList.get(curr, label);
			String host = Test.getHost(label.toString());
			//String new_host = el.getNewHost(host);
			
			int lid = label_lid.get(host); //label_lid.get(new_host);
			
			sb_node.append("" + curr + "\t" + lid + "\n");
			sb_node_count ++;
			if (sb_node_count % 100000 == 0) {
				fw_node.write(sb_node.toString());
				sb_node = new StringBuilder("");
				sb_node.ensureCapacity(1600000);
			}
			while( d-- != 0 ) {
				int succ = successors.nextInt();
				sb_edge.append("" + curr + "\t" + succ + "\n");
				sb_edge_count ++;
				if (sb_edge_count % 100000 == 0) {
					fw_edge.write(sb_edge.toString());
					sb_edge = new StringBuilder("");
					sb_edge.ensureCapacity(2000000);
				}
			}
			
			if (curr > max_node_id) {
				max_node_id = curr;
			}
			if (curr < min_node_id) {
				min_node_id = curr;
			}

			count ++;
			if (count %1000000 ==0 ) System.out.println("progress = " + count + "/" + num_nodes);;
		}
		
		if (sb_node.length() > 0) {
			fw_node.write(sb_node.toString());
		}
		if (sb_edge.length() > 0) {
			fw_edge.write(sb_edge.toString());
		}
		
		fw_node.close();
		fw_edge.close();
		
		concat();
		
		System.out.println("min_node_id="+min_node_id);
		System.out.println("max_node_id="+max_node_id);

		pl.done();
	}
	
	public static void concat () throws Exception {
		String fname1 = "label.txt";
		String fname2 = "edge.txt";
		String fname3 = "clueweb.txt";

		int vno = 0;
		BufferedReader br1 = new BufferedReader(new InputStreamReader(new FileInputStream(fname1), "utf-8"));
		String line_s;
		while ((line_s = br1.readLine()) != null) {
			vno ++;
		}
		br1.close();
		System.out.println("vno=" + vno);
		
		int eno = 0;
		BufferedReader br2 = new BufferedReader(new InputStreamReader(new FileInputStream(fname2), "utf-8"));
		while ((line_s = br2.readLine()) != null) {
			eno ++;
		}
		br2.close();
		System.out.println("eno=" + eno);
		
		OutputStreamWriter fw = new OutputStreamWriter(new FileOutputStream(fname3),"UTF-8");
		br1 = new BufferedReader(new InputStreamReader(new FileInputStream(fname1), "utf-8"));
		br2 = new BufferedReader(new InputStreamReader(new FileInputStream(fname2), "utf-8"));
		fw.write(vno + "\n");
		while ((line_s = br1.readLine()) != null) {
			fw.write(line_s + "\n");
		}
		fw.write(eno + "\n");
		while ((line_s = br2.readLine()) != null) {
			fw.write(line_s + "\n");
		}
		fw.close();
		br1.close();
		br2.close();
	}
}
