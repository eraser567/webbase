package bounded;

public class TestInt {

	public static void main(String[] args) {
		int c = 1000000*1000000;
		System.out.println(c);

	}

}
