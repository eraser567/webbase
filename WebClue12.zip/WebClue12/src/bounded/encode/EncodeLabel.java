package bounded.encode;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.spec.ECFieldF2m;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EncodeLabel {
	
	public static final String PATH = "";//"/Users/huangruizhe/Downloads/WebGraph/webbase/";//

	public static void main(String[] args) {
		try {
			EncodeLabel el = new EncodeLabel();
			el.encode();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void getNewLabels() throws Exception {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		String fname = PATH+"host_count.txt";
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname), "UTF-8"));
		OutputStreamWriter fw = new OutputStreamWriter(new FileOutputStream(PATH + "host_count2.txt"),"UTF-8");
		
		String line = null;
		int count = 0;
		while ((line=br.readLine()) != null) {
			String[] ss = line.split("\t");
			if (ss.length<2) {
				System.err.println(line);
				continue;
			}
			String host = ss[0];
			//String[] hss = host.split("\\.");
			int kcount=Integer.parseInt(ss[1]);
			
			String new_host = getNewHost2(host, kcount);
			/*if (ss[0].contains(".")) {
				new_host = ss[0].substring(ss[0].indexOf('.')+1);
				if (!new_host.contains(".")) {
					new_host = ss[0];
				}
				else if (kcount < 5000 && strChrCount(new_host, '.') >= 2) {
					new_host = new_host.substring(new_host.indexOf('.')+1);
				}
			}
			else {
				new_host = ss[0];
			}*/
			/*if (hss.length == 1 || hss.length == 2) {
				new_host = host;
			}
			else if (hss.length == 3) {
				if (hss[1].length() > 3) {
					new_host = hss[1] + "." + hss[2];
				}
				else {
					new_host = host;
				}
			}
			else if (hss.length == 4) {
				if (hss[2].length() > 3) {
					new_host = hss[2] + "." + hss[3];
				}
				else {
					new_host = hss[1] + "." + hss[2] + "." + hss[3];
				}
			}
			else if (hss.length == 5) {
				if (hss[3].length() > 3) {
					new_host = hss[3] + "." + hss[4];
				}
				else {
					new_host = hss[2] + "." + hss[3] + "." + hss[4];
				}
			}
			else {
				try {
					new_host = hss[hss.length-2] + "." + hss[hss.length-1];
				} catch (Exception e) {
					System.err.println(hss.toString());
					continue;
				}
			}*/
			
			int value = 0;
			if (map.containsKey(new_host)) {
				value = map.get(new_host);
			}
			map.put(new_host, value+Integer.parseInt(ss[1]));
			
			count++;
			if(count%100000==0) {
				System.out.println(count);
			}
		}
		br.close();
		
		System.out.println("new_host.count=" + map.size());
	
	    List<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());
	    Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
	            return (o2.getValue() - o1.getValue()); 
	        }
	    }); 
	    
	    for (Map.Entry<String, Integer> mm : infoIds) {
	    	fw.write(mm.getKey() + "\t" + mm.getValue() + "\n");
	    }
	    		
		fw.close();
		
		int granularity = 1000000;
		int graph_size = 1000000000;
		int[] distr = new int[granularity];
		int[] distr_weight = new int[granularity];
		for (String k : map.keySet()) {
			double d = map.get(k);
			int c = (int) (d/graph_size*granularity); 
			distr[c] ++;
			distr_weight[c] += map.get(k);
		}
		for (int i = 0; i < granularity; i ++) {
			if (distr[i] > 0) {
				System.out.println((i+1) + "\t" + distr[i] + "\t" + distr_weight[i]);				
			}
		}

	}
	
	public HashMap<String, Integer> readLabelId () throws Exception {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		String fname = PATH+"host_count2.txt";
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname), "UTF-8"));
		
		String line = null;
		int count = 1;
		while ((line=br.readLine()) != null) {
			String[] ss = line.split("\t");
			map.put(ss[0], count);
			count ++;
		}
		br.close();
		
		return map;
	}
	
	public HashMap<String, Integer> readLabelId1 () throws Exception {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		String fname = PATH+"label_lid.txt";
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname), "UTF-8"));
		
		String line = null;
		while ((line=br.readLine()) != null) {
			String[] ss = line.split("\t");
			map.put(ss[0], Integer.parseInt(ss[1]));
		}
		br.close();
		
		return map;
	}
	
	public HashMap<String, Integer> readLabelId2 () throws Exception {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		String fname = PATH+"label_lid2.txt";
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname), "UTF-8"));
		
		String line = null;
		while ((line=br.readLine()) != null) {
			String[] ss = line.split("\t");
			map.put(ss[0], Integer.parseInt(ss[1]));
		}
		br.close();
		
		return map;
	}
	
	public String getNewHost (String host) {
		String new_host = null;
		if (host.contains(".")) {
			new_host = host.substring(host.indexOf('.')+1);
			if (!new_host.contains(".")) {
				new_host = host;
			}
		}
		else {
			new_host = host;
		}
		return new_host;
	}
	
	public String getNewHost2 (String host, int kcount) {
		String new_host = null;
		String[] hss = host.split("\\.");
		if (hss.length == 1 || hss.length == 2) {
			new_host = host;
		}
		else if (hss.length == 3) {
			if (hss[1].length() >= 3) {
				new_host = hss[1];
			}
			else {
				new_host = host;
			}
		}
		else if (hss.length == 4) {
			if (hss[2].length() > 3) {
				new_host = hss[2];
			}
			else {
				new_host = hss[1] + "." + hss[2];
			}
		}
		else if (hss.length == 5) {
			if (hss[3].length() > 3) {
				new_host = hss[3];
			}
			else {
				new_host = hss[2] + "." + hss[3];
			}
		}
		else {
			try {
				new_host = hss[hss.length-2] + "." + hss[hss.length-1];
			} catch (Exception e) {
				System.err.println(hss.toString());
				return "s1335233";
			}
		}
		return new_host;
	}
	
	public int strChrCount(String s, char c) {
		int count = 0;
		for (int i = 0; i < s.length(); i ++) {
			if(s.charAt(i) == c) count ++;
		}
		return count;
	}
	
	public void encode () throws Exception {
		HashMap<String, Integer> map = readLabelId2();

		String fname = PATH+"host_count.txt";
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname), "UTF-8"));
		OutputStreamWriter fw = new OutputStreamWriter(new FileOutputStream(PATH + "label_lid.txt"),"UTF-8");
		
		String line = null;
		int count = 0;
		while ((line=br.readLine()) != null) {
			String[] ss = line.split("\t");
			if (ss.length<2) {
				System.err.println(line);
				continue;
			}
			String host = ss[0];
			int kcount = Integer.parseInt(ss[1]);
			
			String new_host = getNewHost2(host, kcount);
			
			int lid = map.get(new_host);
			fw.write(host + "\t" + lid + "\n");
			
			count++;
			if(count%100000==0) {
				System.out.println(count);
			}
		}
		br.close();
		
		fw.close();

	}

}
